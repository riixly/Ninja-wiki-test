@echo off
cd /d "%~dp0"
title Shinobi Fishing Macro
where py >nul 2>&1
if %errorlevel%==0 (
    set "PY=py -3"
) else (
    where python >nul 2>&1
    if errorlevel 1 (
        echo Python is not installed or is missing from PATH.
        echo Install Python from https://www.python.org/downloads/windows/
        echo Make sure you check "Add Python to PATH".
        pause
        exit /b 1
    )
    set "PY=python"
)
%PY% -c "import mss, numpy, PIL, pynput" >nul 2>&1
if errorlevel 1 (
    echo Installing required Python packages. This only happens when needed.
    %PY% -m pip install mss numpy pillow pynput
    if errorlevel 1 (
        echo Package installation failed.
        pause
        exit /b 1
    )
)
%PY% "ShinobiFishingMacro.py"
if errorlevel 1 pause

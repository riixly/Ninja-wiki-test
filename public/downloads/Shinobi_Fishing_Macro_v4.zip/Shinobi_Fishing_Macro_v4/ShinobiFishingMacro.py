"""Shinobi Fishing screenshot-based macro for Windows.

Dependencies: mss, numpy, pillow, pynput (Python 3.9+).
Hotkeys: - (start/pause), = (quit).
Snipping Tool-style fullscreen calibration across all monitors.
"""

from __future__ import annotations

import ctypes
import json
import os
import threading
import time
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

import mss
import numpy as np
from PIL import Image, ImageEnhance, ImageTk
from pynput import keyboard, mouse


CONFIG_PATH = Path(__file__).with_name("fishing_calibration.json")


def enable_per_monitor_dpi_awareness():
    """Make Tk and MSS use physical screen pixels across mixed-DPI displays."""
    if os.name != "nt":
        return
    try:
        # PER_MONITOR_AWARE_V2, supported on modern Windows 10/11.
        if ctypes.windll.user32.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)):
            return
    except (AttributeError, OSError, ValueError):
        pass
    try:
        if ctypes.windll.shcore.SetProcessDpiAwareness(2) == 0:
            return
    except (AttributeError, OSError, ValueError):
        pass
    try:
        ctypes.windll.user32.SetProcessDPIAware()
    except (AttributeError, OSError, ValueError):
        pass


def position_fullscreen_overlay(window, monitor):
    """Place a Tk toplevel at an exact physical multi-monitor coordinate.

    Win32 SetWindowPos is used because Tk geometry strings interpret negative
    offsets as distances from the *right/bottom* of the primary monitor.
    """
    x, y = int(monitor["left"]), int(monitor["top"])
    w, h = int(monitor["width"]), int(monitor["height"])
    window.geometry(f"{w}x{h}+0+0")
    window.update_idletasks()
    if os.name == "nt":
        api = ctypes.windll.user32
        api.GetAncestor.argtypes = [ctypes.c_void_p, ctypes.c_uint]
        api.GetAncestor.restype = ctypes.c_void_p
        api.SetWindowPos.argtypes = [ctypes.c_void_p, ctypes.c_void_p,
                                      ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_int, ctypes.c_uint]
        api.SetWindowPos.restype = ctypes.c_bool
        hwnd = api.GetAncestor(ctypes.c_void_p(window.winfo_id()), 2)  # GA_ROOT
        if not hwnd:
            raise RuntimeError("Could not identify overlay window")
        # HWND_TOPMOST = -1; SWP_SHOWWINDOW = 0x0040
        if not api.SetWindowPos(hwnd, ctypes.c_void_p(-1), x, y, w, h, 0x0040):
            raise OSError("Could not position calibration overlay")
    else:
        # Non-Windows fallback; this macro is designed for Windows.
        window.geometry(f"{w}x{h}{x:+d}{y:+d}")


def absolute_screen_point(monitor, canvas_x, canvas_y):
    """Convert a 1:1 snip canvas coordinate to virtual-desktop coordinates."""
    px = min(max(0, round(canvas_x)), monitor["width"] - 1)
    py = min(max(0, round(canvas_y)), monitor["height"] - 1)
    return monitor["left"] + px, monitor["top"] + py



def longest_run(columns: np.ndarray, min_length: int = 1) -> tuple[int, int] | None:
    """Inclusive endpoints of the longest consecutive sequence of True values."""
    indices = np.flatnonzero(columns)
    if indices.size == 0:
        return None
    splits = np.flatnonzero(np.diff(indices) != 1) + 1
    groups = np.split(indices, splits)
    longest = max(groups, key=len)
    if len(longest) < min_length:
        return None
    return int(longest[0]), int(longest[-1])


def detect_bar(rgb: np.ndarray) -> tuple[float, tuple[int, int]] | None:
    """Return (red_marker_center_x, green_zone_edges) relative to cropped ROI.

    Thresholds intentionally use channel comparisons as well as absolute values,
    so slight brightness differences from Roblox / display settings are okay.
    """
    if rgb.ndim != 3 or rgb.shape[2] != 3:
        return None
    h, w = rgb.shape[:2]
    if h < 10 or w < 90:
        return None

    red = rgb[:, :, 0].astype(np.int16)
    green = rgb[:, :, 1].astype(np.int16)
    blue = rgb[:, :, 2].astype(np.int16)
    green_pixels = (
        (green >= 90)
        & (green > red * 1.5)
        & (green > blue * 1.3)
        & (red < 140)
        & (blue < 145)
    )
    red_pixels = (
        (red >= 140)
        & (red > green * 1.4)
        & (red > blue * 1.4)
        & (green <= 140)
        & (blue <= 145)
    )

    min_column_height = max(4, min(12, int(h * 0.10)))
    green_counts = green_pixels.sum(axis=0)
    red_counts = red_pixels.sum(axis=0)

    # The red marker covers up green pixels when it is inside the target.
    # Bridge this temporary gap before looking for the green rectangle.
    green_columns = green_counts >= min_column_height
    red_run = longest_run(red_counts >= min_column_height, min_length=2)
    if red_run is None:
        return None
    red_left, red_right = red_run
    # Reject very broad red shapes (e.g. a banner selected by mistake).
    if red_right - red_left + 1 > max(45, int(w * 0.09)):
        return None
    green_on_left = np.flatnonzero(green_columns[max(0, red_left - 13):red_left])
    green_on_right = np.flatnonzero(green_columns[red_right + 1:min(w, red_right + 14)])
    if green_on_left.size and green_on_right.size:
        left_last = max(0, red_left - 13) + int(green_on_left[-1])
        right_first = red_right + 1 + int(green_on_right[0])
        green_columns[left_last:right_first + 1] = True

    green_run = longest_run(green_columns, min_length=8)
    if green_run is None:
        return None
    return (red_left + red_right) / 2.0, green_run


def hook_button_visible(rgb: np.ndarray) -> bool:
    """Check for the solid green of the HOOK! button near its saved center.

    The center of the button is often white text, so use a fairly wide patch
    and check the fraction of green pixels, rather than the center pixel.
    """
    if rgb.ndim != 3 or rgb.shape[2] != 3 or rgb.size == 0:
        return False
    r = rgb[:, :, 0].astype(np.int16)
    g = rgb[:, :, 1].astype(np.int16)
    b = rgb[:, :, 2].astype(np.int16)
    green = (g >= 95) & (g > r * 1.45) & (g > b * 1.35) & (r < 140) & (b < 150)
    return float(green.mean()) >= 0.17


class SnippingCalibrator:
    """Windows Snipping Tool-style overlay, one full-screen layer per monitor.

    The desktop freezes behind the snipping overlay instead of opening a
    rescaled screenshot window.  All drawing and pointer coordinates are 1:1
    physical pixels, including monitors placed left/above the main display.
    """

    def __init__(self, master, monitor_shots, on_complete, on_cancel, mode="bar"):
        self.master = master
        self.on_complete = on_complete
        self.on_cancel = on_cancel
        self.stage = mode  # bar -> hook, OR cast
        self.roi = None
        self.drag_start = None
        self.selection = None
        self.views = []
        self.closed = False
        try:
            for monitor, shot in monitor_shots:
                self._add_monitor_overlay(monitor, shot)
            self._show_instructions()
            if self.views:
                self.views[-1]["window"].focus_force()
        except Exception:
            self.close()
            raise

    def _add_monitor_overlay(self, monitor, shot):
        monitor = dict(monitor)
        source = Image.frombytes("RGB", shot.size, shot.rgb)
        # Dim the frozen desktop just as Windows Snipping Tool does.
        darkened = ImageEnhance.Brightness(source).enhance(0.72)
        window = tk.Toplevel(self.master)
        window.withdraw()
        window.overrideredirect(True)
        window.attributes("-topmost", True)
        window.configure(bg="black")
        photo = ImageTk.PhotoImage(darkened, master=window)
        canvas = tk.Canvas(window, width=source.width, height=source.height,
                           highlightthickness=0, bd=0, cursor="crosshair")
        canvas.pack(fill="both", expand=True)
        canvas.create_image(0, 0, anchor="nw", image=photo)
        # Keep a strong instruction band across the top of each display.
        canvas.create_rectangle(0, 0, source.width, 52, fill="#131820", outline="")
        title = canvas.create_text(18, 26, anchor="w", fill="#ffffff",
                                   font=("Segoe UI", 13, "bold"), text="")
        view = {"window": window, "monitor": monitor, "canvas": canvas,
                "photo": photo, "title": title, "outline": None}
        canvas.bind("<ButtonPress-1>", lambda e, v=view: self._mouse_down(v, e))
        canvas.bind("<B1-Motion>", lambda e, v=view: self._mouse_move(v, e))
        canvas.bind("<ButtonRelease-1>", lambda e, v=view: self._mouse_up(v, e))
        window.bind("<Escape>", lambda _: self.cancel())
        window.protocol("WM_DELETE_WINDOW", self.cancel)
        self.views.append(view)
        window.deiconify()
        position_fullscreen_overlay(window, monitor)
        window.lift()

    def _show_instructions(self):
        if self.stage == "cast":
            instruction = "CAST CALIBRATION  |  Click the water where you want to cast    (Esc cancels)"
        elif self.stage == "bar":
            instruction = "STEP 1/2  |  Drag a box around the red/green fishing bar    (Esc cancels)"
        else:
            instruction = "STEP 2/2  |  Click the center of the green HOOK! button    (Esc cancels)"
        for v in self.views:
            v["canvas"].itemconfigure(v["title"], text=instruction)

    def _mouse_down(self, view, event):
        if self.closed:
            return
        if self.stage == "cast":
            self.finish(absolute_screen_point(view["monitor"], event.x, event.y))
            return
        if self.stage == "hook":
            self.finish(self.roi, absolute_screen_point(view["monitor"], event.x, event.y))
            return
        self.selection = view
        self.drag_start = (event.x, event.y)
        if view["outline"] is not None:
            view["canvas"].delete(view["outline"])
        view["outline"] = view["canvas"].create_rectangle(
            event.x, event.y, event.x, event.y,
            outline="#12d9fa", width=3, dash=(9, 4))

    def _mouse_move(self, view, event):
        if self.closed or self.stage != "bar" or self.selection is not view or self.drag_start is None:
            return
        x, y = self.drag_start
        canvas = view["canvas"]
        x1 = min(max(event.x, 0), view["monitor"]["width"] - 1)
        y1 = min(max(event.y, 0), view["monitor"]["height"] - 1)
        canvas.coords(view["outline"], x, y, x1, y1)

    def _mouse_up(self, view, event):
        if self.closed or self.stage != "bar" or self.selection is not view or self.drag_start is None:
            return
        x0, y0 = self.drag_start
        x1, y1 = event.x, event.y
        self.drag_start = None
        self.selection = None
        p0 = absolute_screen_point(view["monitor"], x0, y0)
        p1 = absolute_screen_point(view["monitor"], x1, y1)
        left, top = min(p0[0], p1[0]), min(p0[1], p1[1])
        width, height = abs(p1[0] - p0[0]), abs(p1[1] - p0[1])
        if width < 90 or height < 10:
            # Keep overlays displayed; no separate popup obscures the game.
            self.stage = "bar"
            for v in self.views:
                v["canvas"].itemconfigure(
                    v["title"], text="Selection too small! Drag around the FULL colored bar.    (Esc cancels)")
            return
        self.roi = {"left": left, "top": top, "width": width, "height": height}
        self.stage = "hook"
        self._show_instructions()

    def finish(self, *result):
        if self.closed:
            return
        self.close()
        self.on_complete(*result)

    def cancel(self):
        if self.closed:
            return
        self.close()
        self.on_cancel()

    def close(self):
        if self.closed:
            return
        self.closed = True
        for view in self.views:
            try:
                view["window"].destroy()
            except tk.TclError:
                pass
        self.views.clear()


class FishingMacro:
    def __init__(self):
        enable_per_monitor_dpi_awareness()
        self.root = tk.Tk()
        self.root.title("Shinobi Fishing Macro")
        self.root.attributes("-topmost", True)  # Keep macro controls visible over Roblox.
        self.root.geometry("530x347")
        self.root.resizable(False, False)
        self.root.configure(bg="#17191b")

        self.running = threading.Event()
        self.exiting = threading.Event()
        self.calibration = None
        self.cast_point = None
        self.calibrating = False
        self.calibration_overlay = None
        self.total_clicks = 0
        self.total_casts = 0
        self.last_seen = "No bar detected yet"
        self.last_error = ""
        self.last_hotkey = 0.0
        self.mouse = mouse.Controller()

        self._load_calibration()
        self._draw_ui()
        self.listener = keyboard.Listener(on_press=self._on_key)
        self.listener.start()
        self.worker = threading.Thread(target=self._scan_loop, daemon=True)
        self.worker.start()
        self.root.after(150, self._refresh_status)
        self.root.protocol("WM_DELETE_WINDOW", self.close)

    def _draw_ui(self):
        tk.Label(self.root, text="SHINOBI FISHING", bg="#17191b", fg="#f1ce83", font=("Segoe UI", 17, "bold")).pack(pady=(13, 5))
        tk.Label(self.root, text="-   start / pause             =   close application", bg="#17191b", fg="#f0f0f0", font=("Consolas", 11, "bold")).pack(pady=2)
        self.status_var = tk.StringVar()
        self.details_var = tk.StringVar()
        tk.Label(self.root, textvariable=self.status_var, bg="#17191b", fg="#73eb9a", font=("Segoe UI", 12, "bold")).pack(pady=(12, 3))
        tk.Label(self.root, textvariable=self.details_var, bg="#17191b", fg="#c9ced4", font=("Segoe UI", 10)).pack(pady=2)
        tk.Button(
            self.root, text="CALIBRATE BAR + HOOK", command=self.calibrate,
            bg="#d9a654", fg="#151515", activebackground="#ffce80",
            font=("Segoe UI", 10, "bold"), padx=12, pady=9,
        ).pack(pady=(10, 5))
        tk.Button(
            self.root, text="CALIBRATE CAST (CLICK WATER)", command=self.calibrate_cast,
            bg="#78b6dc", fg="#151515", activebackground="#a4d8f5",
            font=("Segoe UI", 10, "bold"), padx=12, pady=9,
        ).pack(pady=(2, 6))
        tk.Label(
            self.root, text="Drag directly on any monitor; no separate screenshot window.",
            bg="#17191b", fg="#a5a9ac", font=("Segoe UI", 9),
        ).pack()

    def _load_calibration(self):
        try:
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            rect = data.get("roi")
            point = data.get("hook")
            if (isinstance(rect, dict) and isinstance(point, list)
                    and len(point) == 2 and rect.get("width", 0) >= 90
                    and rect.get("height", 0) >= 10):
                self.calibration = (rect, tuple(map(int, point)))
            cast = data.get("cast")
            if isinstance(cast, list) and len(cast) == 2:
                self.cast_point = tuple(map(int, cast))
        except (FileNotFoundError, KeyError, TypeError, ValueError, OSError):
            pass

    def _save_calibration(self):
        data = {}
        if self.calibration is not None:
            roi, hook = self.calibration
            data.update({"roi": roi, "hook": hook})
        if self.cast_point is not None:
            data["cast"] = self.cast_point
        try:
            CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except OSError as exc:
            self.last_error = f"Could not save calibration: {exc}"

    def calibrate(self):
        self._start_calibration("bar")

    def calibrate_cast(self):
        self._start_calibration("cast")

    def _start_calibration(self, mode):
        if self.calibrating:
            return
        self.running.clear()
        self.calibrating = True
        self.last_error = ""
        self.root.withdraw()
        # Give Windows time to hide the topmost app before taking the snip.
        self.root.after(500, lambda: self._capture_calibration(mode))

    def _capture_calibration(self, mode):
        if self.exiting.is_set() or not self.calibrating:
            return
        try:
            with mss.mss() as sct:
                # monitors[0] is the virtual-desktop bounding box; monitors[1:]
                # are ALL actual monitors (including left/above the primary).
                shots = [(dict(mon), sct.grab(mon)) for mon in sct.monitors[1:]]
            if not shots:
                raise RuntimeError("No monitors found")
            finished = self._finished_cast_calibration if mode == "cast" else self._finished_calibration
            self.calibration_overlay = SnippingCalibrator(
                self.root, shots, finished, self._cancel_calibration, mode=mode)
        except Exception as exc:
            self.calibrating = False
            self.root.deiconify()
            self.root.lift()
            messagebox.showerror("Calibration failed", str(exc), parent=self.root)

    def _finished_calibration(self, roi, hook):
        self.calibrating = False
        self.calibration_overlay = None
        self.calibration = (roi, hook)
        self._save_calibration()
        self.last_seen = "Calibration saved. Press - to start."
        self.root.deiconify()
        self.root.lift()  # Restore visibly instead of minimizing after calibration.

    def _finished_cast_calibration(self, cast_point):
        self.calibrating = False
        self.calibration_overlay = None
        self.cast_point = cast_point
        self._save_calibration()
        self.last_seen = "Water casting location saved. Press - to start."
        self.root.deiconify()
        self.root.lift()

    def _cancel_calibration(self):
        self.calibrating = False
        self.calibration_overlay = None
        self.root.deiconify()
        self.root.lift()

    def _on_key(self, key):
        char = getattr(key, "char", None)
        vk = getattr(key, "vk", None)
        is_start = char == "-" or vk in (189, 109)
        is_quit = char == "=" or vk == 187
        if not (is_start or is_quit):
            return
        now = time.monotonic()
        if now - self.last_hotkey < 0.30:
            return  # ignore key repeats
        self.last_hotkey = now
        if is_quit:
            self.exiting.set()
            self.running.clear()
            return False
        if self.calibrating:
            return
        if self.calibration is None:
            self.last_seen = "Calibrate the fishing bar and HOOK! first."
        elif self.running.is_set():
            self.running.clear()
            self.last_seen = "Paused"
        else:
            self.running.set()
            self.last_seen = "Looking for marker + green zone..."

    def _scan_loop(self):
        last_click = 0.0
        can_click = True
        missing_since = None
        idle_since = None
        cast_armed = True
        next_panel_check = 0.0
        panel_present = False

        try:
            with mss.mss() as sct:
                while not self.exiting.is_set():
                    if not self.running.is_set() or self.calibration is None:
                        can_click = True
                        missing_since = None
                        idle_since = None
                        cast_armed = True
                        next_panel_check = 0.0
                        time.sleep(0.06)
                        continue

                    roi, hook_point = self.calibration
                    try:
                        # Directly convert MSS BGRA bytes into RGB array.
                        shot = np.asarray(sct.grab(roi))
                        rgb = shot[:, :, [2, 1, 0]]
                        detected = detect_bar(rgb)
                        now = time.monotonic()
                        # During "Wait for a bite..." the bar is hidden, but
                        # the green HOOK! button is still visible. Check it
                        # periodically so we don't re-cast while waiting or
                        # between hits 1/2/3.
                        if self.cast_point is not None and now >= next_panel_check:
                            x, y = hook_point
                            desktop = sct.monitors[0]
                            left = max(desktop["left"], x - 43)
                            top = max(desktop["top"], y - 17)
                            patch = {
                                "left": left, "top": top,
                                "width": min(86, desktop["left"] + desktop["width"] - left),
                                "height": min(34, desktop["top"] + desktop["height"] - top),
                            }
                            button_shot = np.asarray(sct.grab(patch))
                            button_rgb = button_shot[:, :, [2, 1, 0]]
                            panel_present = hook_button_visible(button_rgb)
                            next_panel_check = now + 0.10
                    except Exception as exc:
                        self.last_error = f"Screen capture failed: {exc}"
                        self.running.clear()
                        continue

                    now = time.monotonic()
                    fishing_ui_visible = detected is not None or panel_present
                    if self.cast_point is not None:
                        if fishing_ui_visible:
                            idle_since = None
                            cast_armed = True  # Re-arm only after seeing a fishing UI.
                        else:
                            if idle_since is None:
                                idle_since = now
                            # UI has ended (or we haven't cast yet). Wait to
                            # avoid casting during a brief round transition.
                            if cast_armed and now - idle_since >= 1.35:
                                try:
                                    previous_position = self.mouse.position
                                    self.mouse.position = self.cast_point
                                    self.mouse.click(mouse.Button.left, 1)
                                    self.mouse.position = previous_position
                                    self.total_casts += 1
                                    self.last_seen = f"Cast #{self.total_casts} sent; waiting for bite..."
                                    cast_armed = False  # No repeated casts while waiting.
                                    can_click = True
                                except Exception as exc:
                                    self.last_error = f"Casting click failed: {exc}"
                                    self.running.clear()
                                time.sleep(0.1)
                                continue
                    if detected is None:
                        if missing_since is None:
                            missing_since = now
                        if now - missing_since > 0.16:
                            can_click = True  # New cast/round after bar disappeared.
                        time.sleep(0.012)
                        continue

                    missing_since = None
                    marker_x, (green_left, green_right) = detected
                    zone_width = green_right - green_left + 1
                    # Stay a few pixels inside the zone to avoid boundary misses.
                    inset = min(max(3, int(zone_width * 0.09)), max(0, (zone_width - 8) // 2))
                    inside = (green_left + inset) <= marker_x <= (green_right - inset)
                    self.last_seen = f"Marker {marker_x:.0f}px  |  Green {green_left}-{green_right}px"

                    if not inside:
                        can_click = True

                    if inside and can_click and now - last_click >= 0.24:
                        try:
                            previous_position = self.mouse.position
                            self.mouse.position = hook_point
                            self.mouse.click(mouse.Button.left, 1)
                            self.mouse.position = previous_position
                            self.total_clicks += 1
                            last_click = time.monotonic()
                            can_click = False
                        except Exception as exc:
                            self.last_error = f"Mouse click failed: {exc}"
                            self.running.clear()
                    time.sleep(0.008)
        except Exception as exc:
            self.last_error = f"Macro worker stopped: {exc}"
            self.running.clear()

    def _refresh_status(self):
        if self.exiting.is_set():
            self.close()
            return
        if self.last_error:
            self.status_var.set("ERROR")
            self.details_var.set(self.last_error[:72])
        elif self.calibration is None:
            self.status_var.set("NOT CALIBRATED")
            self.details_var.set("Snip the bar directly on the monitor running Roblox.")
        elif self.running.is_set():
            self.status_var.set(f"RUNNING  |  {self.total_casts} casts / {self.total_clicks} hooks")
            self.details_var.set(self.last_seen)
        else:
            self.status_var.set(f"READY / PAUSED  |  {self.total_casts} casts / {self.total_clicks} hooks")
            self.details_var.set(self.last_seen if self.cast_point else "Cast point not set: auto-casting disabled.")
        self.root.after(150, self._refresh_status)

    def close(self):
        self.exiting.set()
        if self.calibration_overlay is not None:
            self.calibration_overlay.close()
            self.calibration_overlay = None
        self.running.clear()
        try:
            self.listener.stop()
        except Exception:
            pass
        self.root.destroy()

    def start(self):
        self.root.mainloop()


if __name__ == "__main__":
    FishingMacro().start()

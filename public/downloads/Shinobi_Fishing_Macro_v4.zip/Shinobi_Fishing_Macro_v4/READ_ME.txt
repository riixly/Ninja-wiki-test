SHINOBI FISHING MACRO v4 — WINDOWS (DUAL / MULTIPLE MONITORS)
=============================================================

SETUP
1. Install Python 3 from https://www.python.org/downloads/windows/ if needed.
   Select "Add Python to PATH" during installation.
2. Extract the zip, then double-click START_MACRO.bat.
   If needed, the launcher installs mss, numpy, pillow, and pynput.

CALIBRATION — WINDOWS SNIPPING TOOL STYLE
1. Place Roblox on EITHER monitor, including your secondary display.
   Start a fishing minigame so the red marker, green zone and HOOK! appear.
2. Click CALIBRATE BAR + HOOK in the macro.
   The desktop freezes and dims across ALL connected monitors, like Snipping Tool.
   There is NO separate screenshot-preview window or resized image.
3. On the monitor running Roblox, click and drag a rectangular selection around
   the ENTIRE colored fishing bar (red moving line + green target). Release.
4. Click the center of the HOOK! button to complete bar calibration.
5. Click CALIBRATE CAST (CLICK WATER).
   The same full-screen snipping overlay opens on every monitor.
6. Click on the water where the rod should cast.
7. Press - to start the macro.

CONTROLS (global hotkeys, even with Roblox focused)
-     Start / pause automatic casting and HOOK clicks
=     Quit the app
Esc   Cancel the current calibration overlay

HOW THE MACRO OPERATES
- Detects the red marker and green target in the calibrated bar.
- Clicks your calibrated HOOK! point when the marker is inside green.
- Handles 1-, 2-, and 3-round fishing interactions.
- Uses your water point for auto-casting between attempts.
- Keeps its control window always on top.

NOTES
- Calibrations save in fishing_calibration.json next to the Python script.
  To keep your old v3 settings, copy that JSON into the v4 folder, but
  RE-CALIBRATE if you've moved Roblox to your second monitor.
- The rectangle and click points use real desktop coordinates so 4K primary
  plus a different-resolution or left-positioned secondary screen works.
- Stay in Windows windowed / borderless mode for reliable screen capture.
  Exclusive fullscreen can interfere with capture and simulated clicks.
- Keep the macro control window away from the game area. Some Roblox games
  or clients may block simulated mouse clicks.
- The full-screen selection is a FROZEN overlay, like Windows Snipping Tool.
  Once calibration closes, live game motion resumes normally.
- Live Windows gameplay has not been tested here; adjust if the game
  behaves differently than the screenshots supplied.
